VoicePortMulti

This package contains a generalized Main.cs that can register any number of companion voices in one mod.

Per voice, the only fields you normally need are:
- Name
- InternalName
- Gender

Optional overrides:
- SoundBankName
- PreviewSound
- LocalizationKey

Default conventions:
- SoundBankName = InternalName + "_GVR_ENG"
- PreviewSound = InternalName + "_Test"
- LocalizationKey = InternalName

To add a new voice, edit the Voices array near the top of Main.cs.
