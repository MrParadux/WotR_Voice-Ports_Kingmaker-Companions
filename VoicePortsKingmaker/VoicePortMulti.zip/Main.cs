using HarmonyLib;
using Kingmaker;
using Kingmaker.Blueprints;
using Kingmaker.Blueprints.JsonSystem;
using Kingmaker.Blueprints.Root;
using Kingmaker.Localization;
using Kingmaker.Sound;
using Kingmaker.Visual.Sound;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;
using UnityModManagerNet;

namespace VoicePortMulti;

// This is a template-style, data-driven version of your per-character Main.cs.
// Add more voices by appending to the Voices array.
public static class Main
{
    internal static Harmony HarmonyInstance;
    internal static UnityModManager.ModEntry.ModLogger Log;

    // The only per-character inputs you should normally need:
    //   Name        = display name in the voice list
    //   InternalName = Wwise prefix used for events/bank/preview
    //   Gender      = where it is appended in CharGen
    //
    // Derived automatically:
    //   Display key, preview event, bank name, blueprint GUID
    private static readonly VoiceDefinition[] Voices =
    [
        new VoiceDefinition("Abelard", "VoicePortAbelard", VoiceGender.Male),
        new VoiceDefinition("Kanerah", "VoicePortKanerah", VoiceGender.Female),
        // Add more here:
        // new VoiceDefinition("Cassia", "VoicePortCassia", VoiceGender.Female),
    ];

    public static bool Load(UnityModManager.ModEntry modEntry)
    {
        Log = modEntry.Logger;
        modEntry.OnGUI = OnGUI;

        HarmonyInstance = new Harmony(modEntry.Info.Id);
        try
        {
            HarmonyInstance.PatchAll(Assembly.GetExecutingAssembly());
        }
        catch
        {
            HarmonyInstance.UnpatchAll(HarmonyInstance.Id);
            throw;
        }

        return true;
    }

    public static void OnGUI(UnityModManager.ModEntry modEntry)
    {
    }

    [HarmonyPatch]
    public static class Soundbanks
    {
        private static readonly Dictionary<string, VoiceDefinition> PreviewToVoice =
            Voices.ToDictionary(v => v.PreviewSound, v => v, StringComparer.OrdinalIgnoreCase);

        [HarmonyPatch(typeof(AkAudioService), nameof(AkAudioService.Initialize))]
        [HarmonyPostfix]
        public static void AddBankPaths()
        {
            var banksPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            AkSoundEngine.AddBasePath(banksPath);
        }

        [HarmonyPatch(typeof(UnitAsksComponent), nameof(UnitAsksComponent.PlayPreview))]
        [HarmonyPrefix]
        static bool LoadPreviewBank(UnitAsksComponent __instance)
        {
            if (__instance.PreviewSound is null)
                return true;

            if (!PreviewToVoice.TryGetValue(__instance.PreviewSound, out var voice))
                return true;

            if (!SoundBanksManager.s_Handles.Any(handle =>
                    string.Equals(handle.Key, voice.PreviewSound, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(handle.Key, voice.SoundBankName, StringComparison.OrdinalIgnoreCase)))
            {
                // Keep the existing convention: preview sound is also the bank key.
                SoundBanksManager.LoadBankSync(voice.PreviewSound);
            }

            GameObject gameObject = Game.Instance.UI.Common.gameObject;
            uint previewEventId = AkSoundEngine.GetIDFromString(voice.PreviewSound);
            SoundEventsManager.PostEvent(previewEventId, gameObject);

            return false;
        }

        [HarmonyPatch(typeof(BlueprintsCache), nameof(BlueprintsCache.Init))]
        [HarmonyPostfix]
        static void AddAsksListBlueprints()
        {
            foreach (var voice in Voices)
            {
                AddVoiceBlueprint(voice);
            }
        }

        private static void AddVoiceBlueprint(VoiceDefinition voice)
        {
            LocalizationManager.CurrentPack.PutString(voice.LocalizationKey, voice.Name);

            var blueprint = new BlueprintUnitAsksList
            {
                AssetGuid = new(GuidUtility.Create($"{voice.InternalName}|{voice.Name}|{voice.Gender}")),
                name = $"{voice.InternalName}_Barks",
                DisplayName = new() { m_Key = voice.LocalizationKey }
            };

            blueprint.ComponentsArray =
            [
                new UnitAsksComponent()
                {
                    OwnerBlueprint = blueprint,
                    SoundBanks = [ voice.SoundBankName ],
                    PreviewSound = voice.PreviewSound,

                    // Same structure as your single-character files; only the prefixes differ.
                    Aggro = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_CombatStart_01", 0.0f, 2),
                            Bark($"{voice.InternalName}_CombatStart_02", 0.0f, 2),
                            Bark($"{voice.InternalName}_CombatStart_03", 0.0f, 2),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = true,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    Pain = SingleBarkGroup(voice.InternalName, "Pain", 2.0f, 0),
                    Fatigue = SingleBarkGroup(voice.InternalName, "Fatigue", 60.0f, 0),
                    Death = SingleBarkGroup(voice.InternalName, "Death", 0.0f, 0, true),
                    Unconscious = SingleBarkGroup(voice.InternalName, "Unconscious", 0.0f, 0, true),
                    LowHealth = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_LowHealth_01", 0.0f, 1),
                            Bark($"{voice.InternalName}_LowHealth_02", 0.0f, 1),
                        ],
                        Cooldown = 10.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    CriticalHit = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_CharCrit_01", 0.0f, 2),
                            Bark($"{voice.InternalName}_CharCrit_02", 0.0f, 2),
                            Bark($"{voice.InternalName}_CharCrit_03", 0.0f, 2),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 0.7f,
                        ShowOnScreen = false
                    },
                    Order = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_AttackOrder_01", 0.0f, 3),
                            Bark($"{voice.InternalName}_AttackOrder_02", 0.0f, 3),
                            Bark($"{voice.InternalName}_AttackOrder_03", 0.0f, 3),
                            Bark($"{voice.InternalName}_AttackOrder_04", 0.0f, 3),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    OrderMove = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_Move_01", 0.0f, 4),
                            Bark($"{voice.InternalName}_Move_02", 0.0f, 4),
                            Bark($"{voice.InternalName}_Move_03", 0.0f, 4),
                            Bark($"{voice.InternalName}_Move_04", 0.0f, 4),
                            Bark($"{voice.InternalName}_Move_05", 0.0f, 4),
                            Bark($"{voice.InternalName}_Move_06", 0.0f, 2),
                            Bark($"{voice.InternalName}_Move_07", 0.0f, 4),
                        ],
                        Cooldown = 10.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 0.1f,
                        ShowOnScreen = false
                    },
                    Selected = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_Select_01", 1.0f, 4),
                            Bark($"{voice.InternalName}_Select_02", 1.0f, 4),
                            Bark($"{voice.InternalName}_Select_03", 1.0f, 4),
                            Bark($"{voice.InternalName}_Select_04", 1.0f, 4),
                            Bark($"{voice.InternalName}_Select_05", 1.0f, 4),
                            Bark($"{voice.InternalName}_Select_06", 1.0f, 4),
                            Bark($"{voice.InternalName}_SelectJoke", 0.1f, 30),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    RefuseEquip = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_CantEquip_01", 1.0f, 2),
                            Bark($"{voice.InternalName}_CantEquip_02", 1.0f, 2),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = true,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    RefuseCast = SingleBarkGroup(voice.InternalName, "CantCast", 0.0f, 1, true),
                    CheckSuccess = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_CheckSuccess_01", 1.0f, 2),
                            Bark($"{voice.InternalName}_CheckSuccess_02", 1.0f, 2),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    CheckFail = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_CheckFail_01", 1.0f, 2),
                            Bark($"{voice.InternalName}_CheckFail_02", 1.0f, 2),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    RefuseUnequip = new()
                    {
                        Entries = [],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    Discovery = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_Discovery_01", 0.0f, 1),
                            Bark($"{voice.InternalName}_Discovery_02", 0.0f, 1),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    Stealth = new()
                    {
                        Entries =
                        [
                            Bark($"{voice.InternalName}_StealthMode", 1.0f, 1),
                        ],
                        Cooldown = 0.0f,
                        InterruptOthers = false,
                        DelayMin = 0.0f,
                        DelayMax = 0.0f,
                        Chance = 1.0f,
                        ShowOnScreen = false
                    },
                    StormRain = EmptyGroup(),
                    StormSnow = EmptyGroup(),
                    AnimationBarks =
                    [
                        new()
                        {
                            Entries =
                            [
                                Bark($"{voice.InternalName}_AttackShort", 0.0f, 0),
                            ],
                            Cooldown = 0.0f,
                            InterruptOthers = false,
                            DelayMin = 0.0f,
                            DelayMax = 0.0f,
                            Chance = 0.7f,
                            ShowOnScreen = false,
                            AnimationEvent = MappedAnimationEventType.AttackShort
                        },
                        new()
                        {
                            Entries =
                            [
                                Bark($"{voice.InternalName}_CoupDeGrace", 0.0f, 0),
                            ],
                            Cooldown = 0.0f,
                            InterruptOthers = true,
                            DelayMin = 0.0f,
                            DelayMax = 0.0f,
                            Chance = 1.0f,
                            ShowOnScreen = false,
                            AnimationEvent = MappedAnimationEventType.CoupDeGrace
                        },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.Cast },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.CastDirect },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.CastLong },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.CastShort },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.CastTouch },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.CastYourself },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.Omnicast },
                        new() { Entries = [], Cooldown = 0.0f, InterruptOthers = true, DelayMin = 0.0f, DelayMax = 0.0f, Chance = 1.0f, ShowOnScreen = false, AnimationEvent = MappedAnimationEventType.Precast },
                    ],
                },
            ];

            ResourcesLibrary.BlueprintsCache.AddCachedBlueprint(blueprint.AssetGuid, blueprint);

            if (voice.Gender == VoiceGender.Female)
            {
                BlueprintRoot.Instance.CharGen.m_FemaleVoices = BlueprintRoot.Instance.CharGen.m_FemaleVoices
                    .Append(blueprint.ToReference<BlueprintUnitAsksListReference>())
                    .ToArray();
            }
            else
            {
                BlueprintRoot.Instance.CharGen.m_MaleVoices = BlueprintRoot.Instance.CharGen.m_MaleVoices
                    .Append(blueprint.ToReference<BlueprintUnitAsksListReference>())
                    .ToArray();
            }
        }

        private static UnitAsksComponent.UnitAsksEntry Bark(string akEvent, float randomWeight, int excludeTime) => new()
        {
            Text = null,
            AkEvent = akEvent,
            RandomWeight = randomWeight,
            ExcludeTime = excludeTime,
            m_RequiredFlags = [],
            m_ExcludedFlags = [],
            m_RequiredEtudes = null,
            m_ExcludedEtudes = null
        };

        private static UnitAsksComponent.UnitAsksList EmptyGroup() => new()
        {
            Entries = [],
            Cooldown = 0.0f,
            InterruptOthers = false,
            DelayMin = 0.0f,
            DelayMax = 0.0f,
            Chance = 1.0f,
            ShowOnScreen = false
        };

        private static UnitAsksComponent.UnitAsksList SingleBarkGroup(string prefix, string suffix, float cooldown, int excludeTime, bool interruptOthers = false)
        {
            return new UnitAsksComponent.UnitAsksList
            {
                Entries =
                [
                    Bark($"{prefix}_{suffix}", 0.0f, excludeTime),
                ],
                Cooldown = cooldown,
                InterruptOthers = interruptOthers,
                DelayMin = 0.0f,
                DelayMax = 0.0f,
                Chance = 1.0f,
                ShowOnScreen = false
            };
        }
    }

    public enum VoiceGender
    {
        Female,
        Male
    }

    public sealed class VoiceDefinition
    {
        public string Name { get; }
        public string InternalName { get; }
        public VoiceGender Gender { get; }
        public string SoundBankName { get; }
        public string PreviewSound { get; }
        public string LocalizationKey { get; }

        public VoiceDefinition(string name, string internalName, VoiceGender gender, string? soundBankName = null, string? previewSound = null, string? localizationKey = null)
        {
            Name = name;
            InternalName = internalName;
            Gender = gender;
            SoundBankName = string.IsNullOrWhiteSpace(soundBankName) ? internalName + "_GVR_ENG" : soundBankName;
            PreviewSound = string.IsNullOrWhiteSpace(previewSound) ? internalName + "_Test" : previewSound;
            LocalizationKey = string.IsNullOrWhiteSpace(localizationKey) ? internalName : localizationKey;
        }
    }

    internal static class GuidUtility
    {
        public static Guid Create(string input)
        {
            using var md5 = MD5.Create();
            byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
            hash[6] = (byte)((hash[6] & 0x0F) | (3 << 4));
            hash[8] = (byte)((hash[8] & 0x3F) | 0x80);
            return new Guid(hash);
        }
    }
}
